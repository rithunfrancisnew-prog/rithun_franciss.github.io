RITHUN FRANCIS — PERSONAL PORTFOLIO

FILES
- index.html: complete responsive website (HTML, CSS, JavaScript in one file)

PREVIEW LOCALLY
1. Extract the ZIP.
2. Open index.html in Chrome, Edge, or Firefox.

PUBLISH FREE WITH GITHUB PAGES
1. Create or sign in to a GitHub account.
2. Create a new public repository, for example: rithun-portfolio.
3. Upload index.html to the repository root.
4. Open Settings -> Pages.
5. Under Build and deployment, choose Deploy from a branch.
6. Select the main branch and / (root), then Save.
7. Wait for GitHub to publish the site. The public URL will appear in Settings -> Pages.

BEFORE PUBLISHING
- Replace the generic LinkedIn URL in the Contact section with your actual profile link, or remove that link.
- Add an email address or other contact method you want people to see.
- Review all wording and project descriptions for accuracy.
- The NEXORA card artwork is a CSS concept illustration, not a photograph of the final physical product.
- No analytics, external libraries, or paid services are required.
